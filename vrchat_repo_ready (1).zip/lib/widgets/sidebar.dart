import 'package:flutter/material.dart';
        import 'package:provider/provider.dart';
        import '../providers/auth_provider.dart';

        class VRChatSidebar extends StatelessWidget {
          final int selectedIndex;
          final ValueChanged<int> onDestinationSelected;

          const VRChatSidebar({
            super.key,
            required this.selectedIndex,
            required this.onDestinationSelected,
          });

          @override
          Widget build(BuildContext context) {
            final authProvider = Provider.of<AuthProvider>(context);
            final theme = Theme.of(context);

            return Container(
              width: 72,
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainer,
                border: Border(
                  right: BorderSide(
                    color: theme.colorScheme.outlineVariant,
                    width: 1,
                  ),
                ),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Icon(
                      Icons.vrpano,
                      color: theme.colorScheme.primary,
                      size: 36,
                    ),
                  ),
                  Expanded(
                    child: NavigationRail(
                      selectedIndex: selectedIndex,
                      onDestinationSelected: onDestinationSelected,
                      labelType: NavigationRailLabelType.all,
                      destinations: const [
                        NavigationRailDestination(
                          icon: Icon(Icons.people),
                          label: Text('Friends'),
                        ),
                        NavigationRailDestination(
                          icon: Icon(Icons.public),
                          label: Text('Worlds'),
                        ),
                        NavigationRailDestination(
                          icon: Icon(Icons.person),
                          label: Text('Profile'),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: IconButton(
                      icon: const Icon(Icons.logout),
                      color: theme.colorScheme.error,
                      onPressed: () {
                        authProvider.logout();
                      },
                      tooltip: 'Logout',
                    ),
                  ),
                ],
              ),
            );
          }
        }