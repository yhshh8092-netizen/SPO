import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

/// Talks to the VRChat API directly over HTTP instead of relying on the
/// vrchat_dart package, whose published versions ship a broken internal
/// dependency (its convenience extensions reference a `LimitedUser` type
/// that doesn't exist in the API model version it depends on).
class AuthProvider extends ChangeNotifier {
  static const _baseUrl = 'https://api.vrchat.cloud/api/1';
  // VRChat's long-standing public web API key, required on every request.
  static const _apiKey = 'JlE5Jldo5Jibnk5O5hTx6XVqsJu4WJ26';

  final Dio _dio = Dio(BaseOptions(
    baseUrl: _baseUrl,
    headers: {
      'User-Agent': 'VRCPortal/1.0 (contact@example.com)',
    },
  ));
  final _CookieJar _cookies = _CookieJar();

  Dio? get api => _isAuthenticated ? _dio : null;

  bool _isAuthenticated = false;
  String? _currentUsername;
  String? _error;
  String? _twoFactorMethod; // 'totp' or 'emailotp'

  bool get isAuthenticated => _isAuthenticated;
  String? get currentUsername => _currentUsername;
  String? get error => _error;
  String? get twoFactorMethod => _twoFactorMethod;

  String _basicAuthHeader(String username, String password) {
    final raw = '${Uri.encodeComponent(username)}:${Uri.encodeComponent(password)}';
    return 'Basic ${base64Encode(utf8.encode(raw))}';
  }

  Future<bool> login(String username, String password) async {
    _error = null;
    try {
      _dio.options.headers['Authorization'] = _basicAuthHeader(username, password);
      _dio.options.headers['Cookie'] = _cookies.header;

      final res = await _dio.get('/auth/user', queryParameters: {'apiKey': _apiKey});
      _cookies.absorb(res.headers['set-cookie']);

      final data = res.data as Map<String, dynamic>;
      if (data['requiresTwoFactorAuth'] != null) {
        final methods = List<String>.from(data['requiresTwoFactorAuth']);
        _twoFactorMethod = methods.contains('totp') ? 'totp' : 'emailotp';
        notifyListeners();
        return false;
      }

      _isAuthenticated = true;
      _currentUsername = data['displayName'] ?? data['username'] ?? 'User';
      notifyListeners();
      return true;
    } on DioException catch (e) {
      _error = 'Login failed: ${_describeError(e)}';
      _isAuthenticated = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> verifyTwoFactor(String code) async {
    _error = null;
    try {
      final endpoint = _twoFactorMethod == 'totp'
          ? '/auth/twofactorauth/totp/verify'
          : '/auth/twofactorauth/emailotp/verify';

      _dio.options.headers['Cookie'] = _cookies.header;
      final verifyRes = await _dio.post(
        endpoint,
        queryParameters: {'apiKey': _apiKey},
        data: {'code': code},
      );
      _cookies.absorb(verifyRes.headers['set-cookie']);

      _dio.options.headers['Cookie'] = _cookies.header;
      final res = await _dio.get('/auth/user', queryParameters: {'apiKey': _apiKey});
      final data = res.data as Map<String, dynamic>;

      _isAuthenticated = true;
      _currentUsername = data['displayName'] ?? data['username'] ?? 'User';
      _twoFactorMethod = null;
      notifyListeners();
      return true;
    } on DioException catch (e) {
      _error = 'Verification failed: ${_describeError(e)}';
      notifyListeners();
      return false;
    }
  }

  String _describeError(DioException e) {
    if (e.type == DioExceptionType.connectionError) {
      return 'could not reach the VRChat API';
    }
    final data = e.response?.data;
    if (data is Map && data['error'] != null) {
      return data['error']['message']?.toString() ?? e.message ?? 'unknown error';
    }
    return e.message ?? 'unknown error';
  }

  void logout() {
    _isAuthenticated = false;
    _currentUsername = null;
    _error = null;
    _twoFactorMethod = null;
    _cookies.clear();
    _dio.options.headers.remove('Authorization');
    _dio.options.headers.remove('Cookie');
    notifyListeners();
  }
}

/// Minimal cookie jar: VRChat tracks the session (and 2FA state) via a
/// cookie it sets on login, so requests after login need to send it back.
/// This avoids pulling in a full cookie-jar package for one cookie.
class _CookieJar {
  final Map<String, String> _cookies = {};

  void absorb(List<String>? setCookieHeaders) {
    if (setCookieHeaders == null) return;
    for (final raw in setCookieHeaders) {
      final firstPart = raw.split(';').first;
      final eq = firstPart.indexOf('=');
      if (eq == -1) continue;
      _cookies[firstPart.substring(0, eq).trim()] = firstPart.substring(eq + 1).trim();
    }
  }

  String get header => _cookies.entries.map((e) => '${e.key}=${e.value}').join('; ');

  void clear() => _cookies.clear();
}
