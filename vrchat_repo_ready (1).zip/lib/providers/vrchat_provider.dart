import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../models/vrchat_models.dart';

class VRChatProvider extends ChangeNotifier {
  static const _apiKey = 'JlE5Jldo5Jibnk5O5hTx6XVqsJu4WJ26';

  List<VRChatUser> _friends = [];
  List<VRChatWorld> _activeWorlds = [];
  bool _loading = false;

  List<VRChatUser> get friends => _friends;
  List<VRChatWorld> get activeWorlds => _activeWorlds;
  bool get loading => _loading;

  Future<void> loadFriends(Dio api) async {
    _loading = true;
    notifyListeners();

    try {
      final res = await api.get(
        '/auth/user/friends',
        queryParameters: {'apiKey': _apiKey, 'offline': false, 'n': 100},
      );
      final list = (res.data as List).cast<Map<String, dynamic>>();
      _friends = list.map((json) => VRChatUser.fromJson(json)).toList();
    } catch (e) {
      debugPrint('Error loading friends: $e');
    }

    _loading = false;
    notifyListeners();
  }

  Future<void> loadActiveWorlds(Dio api) async {
    _loading = true;
    notifyListeners();

    try {
      final res = await api.get(
        '/worlds/active',
        queryParameters: {'apiKey': _apiKey, 'n': 20},
      );
      final list = (res.data as List).cast<Map<String, dynamic>>();
      _activeWorlds = list.map((json) => VRChatWorld.fromJson(json)).toList();
    } catch (e) {
      debugPrint('Error loading worlds: $e');
    }

    _loading = false;
    notifyListeners();
  }
}
