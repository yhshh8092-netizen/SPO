import 'package:flutter/material.dart';
        import 'package:provider/provider.dart';
        import 'package:cached_network_image/cached_network_image.dart';
        import '../providers/auth_provider.dart';
        import '../providers/vrchat_provider.dart';

        class WorldsScreen extends StatefulWidget {
          const WorldsScreen({super.key});

          @override
          State<WorldsScreen> createState() => _WorldsScreenState();
        }

        class _WorldsScreenState extends State<WorldsScreen> {
          @override
          void initState() {
            super.initState();
            _loadData();
          }

          Future<void> _loadData() async {
            final auth = Provider.of<AuthProvider>(context, listen: false);
            final provider = Provider.of<VRChatProvider>(context, listen: false);

            if (auth.isAuthenticated && auth.api != null) {
              await provider.loadActiveWorlds(auth.api!);
            }
          }

          @override
          Widget build(BuildContext context) {
            final provider = Provider.of<VRChatProvider>(context);
            final theme = Theme.of(context);

            return Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Active Worlds',
                    style: theme.textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${provider.activeWorlds.length} worlds available',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: provider.loading
                        ? const Center(child: CircularProgressIndicator())
                        : provider.activeWorlds.isEmpty
                            ? Center(
                                child: Text(
                                  'No worlds found',
                                  style: theme.textTheme.bodyLarge?.copyWith(
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                ),
                              )
                            : GridView.builder(
                                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 3,
                                  childAspectRatio: 1.6,
                                  crossAxisSpacing: 16,
                                  mainAxisSpacing: 16,
                                ),
                                itemCount: provider.activeWorlds.length,
                                itemBuilder: (context, index) {
                                  final world = provider.activeWorlds[index];
                                  return _WorldCard(world: world);
                                },
                              ),
                  ),
                ],
              ),
            );
          }
        }

        class _WorldCard extends StatelessWidget {
          final dynamic world;

          const _WorldCard({required this.world});

          @override
          Widget build(BuildContext context) {
            final theme = Theme.of(context);

            return Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 3,
                    child: world.imageUrl != null
                        ? CachedNetworkImage(
                            imageUrl: world.imageUrl,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            placeholder: (context, url) => Container(
                              color: theme.colorScheme.surfaceContainerHigh,
                              child: const Center(child: CircularProgressIndicator()),
                            ),
                            errorWidget: (context, url, error) => Container(
                              color: theme.colorScheme.surfaceContainerHigh,
                              child: Icon(
                                Icons.image_not_supported,
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          )
                        : Container(
                            color: theme.colorScheme.surfaceContainerHigh,
                            child: Icon(
                              Icons.public,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          world.name,
                          style: theme.textTheme.titleSmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Icon(Icons.people, size: 14, color: theme.colorScheme.onSurfaceVariant),
                            const SizedBox(width: 4),
                            Text(
                              '${world.visitors}/${world.capacity}',
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }
        }