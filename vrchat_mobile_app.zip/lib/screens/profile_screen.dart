import 'package:flutter/material.dart';
        import 'package:provider/provider.dart';
        import '../providers/auth_provider.dart';

        class ProfileScreen extends StatelessWidget {
          const ProfileScreen({super.key});

          @override
          Widget build(BuildContext context) {
            final authProvider = Provider.of<AuthProvider>(context);
            final theme = Theme.of(context);

            return Padding(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 500),
                  child: Card(
                    elevation: 4,
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CircleAvatar(
                            radius: 64,
                            backgroundColor: theme.colorScheme.primaryContainer,
                            child: Text(
                              authProvider.currentUsername?.substring(0, 1).toUpperCase() ?? '?',
                              style: TextStyle(
                                fontSize: 48,
                                color: theme.colorScheme.onPrimaryContainer,
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            authProvider.currentUsername ?? 'User',
                            style: theme.textTheme.headlineSmall,
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.primaryContainer,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Text(
                              'Online',
                              style: TextStyle(
                                color: theme.colorScheme.onPrimaryContainer,
                              ),
                            ),
                          ),
                          const SizedBox(height: 32),
                          Divider(color: theme.colorScheme.outlineVariant),
                          const SizedBox(height: 16),
                          _ProfileInfoRow(
                            icon: Icons.verified,
                            label: 'VRChat+',
                            value: 'Active',
                          ),
                          _ProfileInfoRow(
                            icon: Icons.cake,
                            label: 'Joined',
                            value: '2024',
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          }
        }

        class _ProfileInfoRow extends StatelessWidget {
          final IconData icon;
          final String label;
          final String value;

          const _ProfileInfoRow({
            required this.icon,
            required this.label,
            required this.value,
          });

          @override
          Widget build(BuildContext context) {
            final theme = Theme.of(context);
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: [
                  Icon(icon, size: 20, color: theme.colorScheme.onSurfaceVariant),
                  const SizedBox(width: 16),
                  Text(
                    label,
                    style: theme.textTheme.bodyMedium,
                  ),
                  const Spacer(),
                  Text(
                    value,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            );
          }
        }