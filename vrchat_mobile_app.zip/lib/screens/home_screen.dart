import 'package:flutter/material.dart';
        import 'package:provider/provider.dart';
        import '../providers/auth_provider.dart';
        import '../providers/vrchat_provider.dart';
        import '../widgets/sidebar.dart';
        import 'login_screen.dart';
        import 'friends_screen.dart';
        import 'worlds_screen.dart';
        import 'profile_screen.dart';

        class HomeScreen extends StatefulWidget {
          const HomeScreen({super.key});

          @override
          State<HomeScreen> createState() => _HomeScreenState();
        }

        class _HomeScreenState extends State<HomeScreen> {
          int _selectedIndex = 0;

          @override
          Widget build(BuildContext context) {
            return Scaffold(
              body: Row(
                children: [
                  VRChatSidebar(
                    selectedIndex: _selectedIndex,
                    onDestinationSelected: (index) {
                      setState(() {
                        _selectedIndex = index;
                      });
                    },
                  ),
                  Expanded(
                    child: _buildContent(),
                  ),
                ],
              ),
            );
          }

          Widget _buildContent() {
            final authProvider = Provider.of<AuthProvider>(context);

            if (!authProvider.isAuthenticated) {
              return const LoginScreen();
            }

            switch (_selectedIndex) {
              case 0:
                return const FriendsScreen();
              case 1:
                return const WorldsScreen();
              case 2:
                return const ProfileScreen();
              default:
                return const Center(child: Text('Select a section'));
            }
          }
        }