import 'package:flutter/material.dart';
        import 'package:provider/provider.dart';
        import 'package:cached_network_image/cached_network_image.dart';
        import '../providers/auth_provider.dart';
        import '../providers/vrchat_provider.dart';

        class FriendsScreen extends StatefulWidget {
          const FriendsScreen({super.key});

          @override
          State<FriendsScreen> createState() => _FriendsScreenState();
        }

        class _FriendsScreenState extends State<FriendsScreen> {
          @override
          void initState() {
            super.initState();
            _loadData();
          }

          Future<void> _loadData() async {
            final auth = Provider.of<AuthProvider>(context, listen: false);
            final provider = Provider.of<VRChatProvider>(context, listen: false);

            if (auth.isAuthenticated && auth.api != null) {
              await provider.loadFriends(auth.api!);
            }
          }

          @override
          Widget build(BuildContext context) {
            final provider = Provider.of<VRChatProvider>(context);
            final theme = Theme.of(context);

            return Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Friends',
                    style: theme.textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${provider.friends.length} friends online',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: provider.loading
                        ? const Center(child: CircularProgressIndicator())
                        : provider.friends.isEmpty
                            ? Center(
                                child: Text(
                                  'No friends online',
                                  style: theme.textTheme.bodyLarge?.copyWith(
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                ),
                              )
                            : ListView.builder(
                                itemCount: provider.friends.length,
                                itemBuilder: (context, index) {
                                  final friend = provider.friends[index];
                                  return _FriendListItem(friend: friend);
                                },
                              ),
                  ),
                ],
              ),
            );
          }
        }

        class _FriendListItem extends StatelessWidget {
          final dynamic friend;

          const _FriendListItem({required this.friend});

          @override
          Widget build(BuildContext context) {
            final theme = Theme.of(context);

            return Card(
              margin: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundImage: friend.profilePicOverride != null
                      ? CachedNetworkImageProvider(friend.profilePicOverride)
                      : null,
                  child: friend.profilePicOverride == null
                      ? Text(friend.displayName[0].toUpperCase())
                      : null,
                ),
                title: Text(friend.displayName),
                subtitle: Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: friend.status == 'online'
                            ? Colors.green
                            : friend.status == 'active'
                                ? Colors.orange
                                : Colors.grey,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(friend.status),
                  ],
                ),
                trailing: Icon(
                  Icons.chevron_right,
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            );
          }
        }