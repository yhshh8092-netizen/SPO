class VRChatUser {
          final String id;
          final String username;
          final String displayName;
          final String? profilePicOverride;
          final String status;
          final String? currentAvatarImageUrl;

          VRChatUser({
            required this.id,
            required this.username,
            required this.displayName,
            this.profilePicOverride,
            required this.status,
            this.currentAvatarImageUrl,
          });

          factory VRChatUser.fromJson(Map<String, dynamic> json) {
            return VRChatUser(
              id: json['id'] ?? '',
              username: json['username'] ?? '',
              displayName: json['displayName'] ?? json['username'] ?? 'Unknown',
              profilePicOverride: json['profilePicOverride'],
              status: json['status'] ?? 'offline',
              currentAvatarImageUrl: json['currentAvatarImageUrl'],
            );
          }
        }

        class VRChatWorld {
          final String id;
          final String name;
          final String description;
          final String? imageUrl;
          final int capacity;
          final int visitors;

          VRChatWorld({
            required this.id,
            required this.name,
            required this.description,
            this.imageUrl,
            required this.capacity,
            required this.visitors,
          });

          factory VRChatWorld.fromJson(Map<String, dynamic> json) {
            return VRChatWorld(
              id: json['id'] ?? '',
              name: json['name'] ?? 'Unknown World',
              description: json['description'] ?? '',
              imageUrl: json['imageUrl'],
              capacity: json['capacity'] ?? 0,
              visitors: json['visitors'] ?? 0,
            );
          }
        }