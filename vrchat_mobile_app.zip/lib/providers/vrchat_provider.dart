import 'package:flutter/material.dart';
        import 'package:vrchat_dart/vrchat_dart.dart' as vrchat;
        import '../models/vrchat_models.dart';

        class VRChatProvider extends ChangeNotifier {
          List<VRChatUser> _friends = [];
          List<VRChatWorld> _activeWorlds = [];
          bool _loading = false;

          List<VRChatUser> get friends => _friends;
          List<VRChatWorld> get activeWorlds => _activeWorlds;
          bool get loading => _loading;

          Future<void> loadFriends(vrchat.VRChatApi api) async {
            _loading = true;
            notifyListeners();

            try {
              final response = await api.friendsApi.getFriends();
              _friends = response.map((user) => VRChatUser.fromJson(user.toJson())).toList();
            } catch (e) {
              debugPrint('Error loading friends: $e');
            }

            _loading = false;
            notifyListeners();
          }

          Future<void> loadActiveWorlds(vrchat.VRChatApi api) async {
            _loading = true;
            notifyListeners();

            try {
              final response = await api.worldsApi.getActiveWorlds(n: 20);
              _activeWorlds = response.map((world) => VRChatWorld.fromJson(world.toJson())).toList();
            } catch (e) {
              debugPrint('Error loading worlds: $e');
            }

            _loading = false;
            notifyListeners();
          }
        }