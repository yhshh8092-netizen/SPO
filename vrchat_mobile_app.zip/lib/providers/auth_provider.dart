import 'package:flutter/material.dart';
        import 'package:vrchat_dart/vrchat_dart.dart' as vrchat;

        class AuthProvider extends ChangeNotifier {
          vrchat.VRChatApi? _api;
          bool _isAuthenticated = false;
          String? _currentUsername;
          String? _error;

          vrchat.VRChatApi? get api => _api;
          bool get isAuthenticated => _isAuthenticated;
          String? get currentUsername => _currentUsername;
          String? get error => _error;

          Future<bool> login(String username, String password) async {
            _error = null;
            try {
              final config = vrchat.Configuration(
                basePath: 'https://api.vrchat.cloud/api/1',
                apiKey: 'JlE5Jldo5Jibnk5O5hTx6XVqsJu4WJ26',
              );

              _api = vrchat.VRChatApi(config);
              final user = await _api!.authenticationApi.getCurrentUser();

              _isAuthenticated = true;
              _currentUsername = user.displayName ?? user.username ?? 'User';
              notifyListeners();
              return true;
            } catch (e) {
              _error = 'Login failed: ${e.toString()}';
              _isAuthenticated = false;
              notifyListeners();
              return false;
            }
          }

          void logout() {
            _api = null;
            _isAuthenticated = false;
            _currentUsername = null;
            notifyListeners();
          }
        }