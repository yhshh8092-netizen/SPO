import 'package:flutter/material.dart';
        import 'package:provider/provider.dart';
        import 'screens/home_screen.dart';
        import 'providers/auth_provider.dart';
        import 'providers/vrchat_provider.dart';

        void main() {
          runApp(const MyApp());
        }

        class MyApp extends StatelessWidget {
          const MyApp({super.key});

          @override
          Widget build(BuildContext context) {
            return MultiProvider(
              providers: [
                ChangeNotifierProvider(create: (_) => AuthProvider()),
                ChangeNotifierProvider(create: (_) => VRChatProvider()),
              ],
              child: MaterialApp(
                title: 'VRChat Mobile',
                theme: ThemeData(
                  colorScheme: ColorScheme.fromSeed(
                    seedColor: Colors.deepPurple,
                    brightness: Brightness.dark,
                  ),
                  useMaterial3: true,
                ),
                home: const HomeScreen(),
                debugShowCheckedModeBanner: false,
              ),
            );
          }
        }